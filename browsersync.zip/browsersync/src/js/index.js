;(function(win,doc){
	function xx(){
		return '<div><img src="../images/bj.jpg"/></div>';
	}
	xx();
})(window,document);