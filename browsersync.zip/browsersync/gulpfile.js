var gulp = require('gulp'),
    browserSync = require('browser-sync').create(),
    reload = browserSync.reload,

    cssmin = require('gulp-clean-css'),         //压缩css
    jshint = require('gulp-jshint'),              //检查js代码
    uglify = require('gulp-uglify'),              //压缩js
    htmlmin = require('gulp-htmlmin'),            //压缩html
    rename = require('gulp-rename'),              //修改文件名
    concat = require('gulp-concat'),              //合并文件
    rev = require('gulp-rev'),                    //生成md5的文件指纹
    revreplace = require('gulp-rev-replace'),     //重写 md5指纹文件名
    revCollector = require('gulp-rev-collector'), //
    urlreplace = require('gulp-url-replace'),      //url 前缀修改
    postcss    = require('gulp-postcss'),           //css处理器
    plumber = require('gulp-plumber'),              //防止报错而终止任务
    fileinclude = require('gulp-file-include'),     //用include 合并文件
    requireDir = require('require-dir'),            //分任务到不同的文件
    fs = require('fs');

var baseUrl = 'http://localhost:8080/';

// 压缩css
gulp.task('css', function () {
    var postcssArr = [
            require('autoprefixer')({
                browsers: ['last 2 versions', 'Android >= 4.0'],
                cascade: false, //是否美化属性值 默认：true 像这样：
                //-webkit-transform: rotate(45deg);
                //transform: rotate(45deg);
                remove:true //是否去掉不必要的前缀 默认：true 
            }),
            require('precss'),
            require('postcss-assets')({
                loadPaths: ['src/images/'],
                baseUrl: baseUrl,
                cachebuster: true
            })
        ];
    var manifest = gulp.src("/output/static/{font,images}/*.json");
    return gulp.src(['src/**/*.css','!src/**/_*.css'])
        .pipe(plumber())
        .pipe(postcss(postcssArr))
        .pipe(rev())
        .pipe(cssmin({
            advanced: false,//类型：Boolean 默认：true [是否开启高级优化（合并选择器等）]
            compatibility: 'ie7',//保留ie7及以下兼容写法 类型：String 默认：''or'*' [启用兼容模式； 'ie7'：IE7兼容模式，'ie8'：IE8兼容模式，'*'：IE9+兼容模式]
            keepBreaks: false,//类型：Boolean 默认：false [是否保留换行]
            keepSpecialComments: '*'
            //保留所有特殊前缀 当你用autoprefixer生成的浏览器前缀，如果不加这个参数，有可能将会删除你的部分前缀
        }))
        .pipe( revreplace({manifest: manifest}) )
        .pipe( urlreplace({
            '../font': baseUrl+'font',
            '/src/': ''
        }))
        .pipe(gulp.dest('dist/'))
        .pipe(rev.manifest())
        .pipe(gulp.dest('dist/rev/css'));
});
// 压缩js
gulp.task('js', function () {
    var manifest = gulp.src("/output/static/{images,html}/*.json");
    gulp.src('src/js/**/*.js')
        .pipe(plumber())  //
        .pipe(rev())
        // .pipe(jshint.reporter('default')) //参数太多不好选，暂时不用
        .pipe(uglify())
        .pipe( revreplace({manifest: manifest}) )
        .pipe(urlreplace({
            '../images': baseUrl+'images'
        }))
        .pipe(gulp.dest('dist/js'))
        .pipe(rev.manifest())
        .pipe(gulp.dest('dist/rev/js'));
});
// 压缩
gulp.task('fontImg', function () {
    gulp.src('src/font/**/*')
        .pipe(plumber())  //
        .pipe(rev())
        .pipe(gulp.dest('dist/font'))
        .pipe(rev.manifest())
        .pipe(gulp.dest('dist/rev/font'));
    gulp.src('src/images/**/*{png,jpg,jpeg,gif,svg}')
        .pipe(plumber())  //
        .pipe(rev())
        .pipe(gulp.dest('dist/images'))
        .pipe(rev.manifest())
        .pipe(gulp.dest('dist/rev/images'));
});
// 压缩html
gulp.task('html',['fontImg','css','js'], function(){
    var options = {
        removeComments: true,//清除HTML注释
        collapseWhitespace: true,//压缩HTML
        collapseBooleanAttributes: true,//省略布尔属性的值 <input checked="true"/> ==> <input />
        removeEmptyAttributes: true,//删除所有空格作属性值 <input id="" /> ==> <input />
        removeScriptTypeAttributes: true,//删除<script>的type="text/javascript"
        removeStyleLinkTypeAttributes: false,//删除<style>和<link>的type="text/css"
        minifyJS: true,//压缩页面JS
        minifyCSS: true//压缩页面CSS
    },
    manifest = gulp.src("dist/**/rev-manifest.json");
    gulp.src(['src/html/**/*.html','!src/html/template/**/*.html'])
        .pipe(plumber())  //阻止 gulp 插件发生错误导致进程退出并输出错误日志
        .pipe(revCollector())
        .pipe(revreplace({manifest: manifest}))
        .pipe(urlreplace({
            '../js': baseUrl+'js',
            '../css': baseUrl+'css'
        }))
        .pipe(fileinclude({
            prefix: '@@',
            basepath: '@file'
        }))
        .pipe(htmlmin(options)) //压缩html
        .pipe(gulp.dest('dist/html'));
});

gulp.task('browser-sync',function(){
    gulp.start('html');
    browserSync.init({
        server:{
            baseDir:'dist',
            index: "/html/index.html" 
        },
        port: 8080
    });    
});